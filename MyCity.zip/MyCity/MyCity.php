<?php
/*
Plugin Name: My City Plugin
Description: Плагин для определения города посетителя сайта.
Version: 1.2
Author: Sasha0Basha
*/

// Определение констант для обновлений плагина
define('MY_CITY_PLUGIN_VERSION', '1.0');
define('MY_CITY_PLUGIN_SLUG', 'my-city-plugin');
define('MY_CITY_PLUGIN_FILE', __FILE__);

// Хук для проверки обновлений при активации плагина
register_activation_hook(__FILE__, 'my_city_plugin_activation');
function my_city_plugin_activation() {
    add_action('init', 'my_city_plugin_update');
}

// Функция для проверки и загрузки обновлений плагина
function my_city_plugin_update() {
    $remote_version = 'latest'; // Получение последней версии из GitHub

    if (version_compare(MY_CITY_PLUGIN_VERSION, $remote_version, '<')) {
        $zip_url = 'https://github.com/Sasha0Basha/MyCity/blob/main/MyCity.zip'; // Замените на URL вашего репозитория
        $temp_file = download_url($zip_url);

        if (!is_wp_error($temp_file)) {
            $zip = new ZipArchive;
            $extract_path = WP_PLUGIN_DIR . '/' . MY_CITY_PLUGIN_SLUG;

            if ($zip->open($temp_file) === true) {
                $zip->extractTo($extract_path);
                $zip->close();
                unlink($temp_file);
            }

            update_option(MY_CITY_PLUGIN_SLUG . '_version', $remote_version);
        }
    }
}

// Функция для определения города по IP адресу с помощью ipinfo.io
function get_user_city() {
    $user_ip = $_SERVER['REMOTE_ADDR']; // Получаем IP адрес посетителя сайта
    $api_response = wp_remote_get('https://ipinfo.io/'.$user_ip.'/json'); // Запрос к API для получения информации о местоположении по IP

    if (!is_wp_error($api_response)) {
        $body = wp_remote_retrieve_body($api_response);
        $data = json_decode($body);

        if ($data && isset($data->city)) {
            return $data->city; // Возвращаем название города
        } else {
            return 'Не удалось определить ваш город';
        }
    } else {
        return 'Произошла ошибка при получении данных о вашем местоположении';
    }
}

// Функция для вывода информации о городе посетителя
function display_user_city() {
    $user_city = get_user_city(); // Получаем город пользователя

    echo 'Ваш город - ' . $user_city; // Выводим информацию на страницу
}

// Хук для вывода информации о городе в нужном месте на сайте
function display_city_on_site() {
    ob_start();
    display_user_city();
    $output = ob_get_clean();
    echo '<div>' . $output . '</div>';
}
add_action('wp_footer', 'display_city_on_site');
